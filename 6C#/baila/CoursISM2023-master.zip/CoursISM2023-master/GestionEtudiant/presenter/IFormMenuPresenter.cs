﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionEtudiant.presenter
{
    public interface IFormMenuPresenter
    {
        void showClasseHandler(Object sender, EventArgs e);
    }
}
